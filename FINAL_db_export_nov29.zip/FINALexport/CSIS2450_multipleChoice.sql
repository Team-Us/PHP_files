CREATE DATABASE  IF NOT EXISTS `CSIS2450` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `CSIS2450`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: CSIS2450
-- ------------------------------------------------------
-- Server version	5.5.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `multipleChoice`
--

DROP TABLE IF EXISTS `multipleChoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multipleChoice` (
  `Eid` int(11) NOT NULL,
  `OptionA` varchar(200) DEFAULT NULL,
  `OptionB` varchar(200) DEFAULT NULL,
  `OptionC` varchar(200) DEFAULT NULL,
  `OptionD` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Eid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multipleChoice`
--

LOCK TABLES `multipleChoice` WRITE;
/*!40000 ALTER TABLE `multipleChoice` DISABLE KEYS */;
INSERT INTO `multipleChoice` VALUES (1,'double','String','char','int'),(2,'Several Strings','One String','A secrete message','The strangest int I\'ve ever seen.'),(3,'char','String','int','double'),(7,'String','Boolean','Int','Char'),(9,'Int distance = 1.78;','double distance = 1.78;','String distance = 1.78;','Integer distance = 1.78;'),(10,'string movie =\'Attack of the Killer Tomatoes\';','String movie = Attack of the Killer Tomatoes;','String movie =\"Attack of the Killer Tomatoes\";','String Attack of the Killer Tomatoes = movie;'),(11,'int total=6;','float total=6.1;','char total= \'6\';','double Total= 6.0;'),(17,'Imprort Scanner;','Import New Scanner;','import java.utli.Scanner;','Import util.Scanner.User;'),(18,'System.in','System.input','System.out','System.retrieve'),(19,'After the class declaration.','With the fields withing the class.','Before the class declaration.','Within the main method.'),(23,'if (chr = \"a\") System.out.print(\"true\");','if (chr == \"a\") System.out.print(\"true\");','if (chr = \'a\') System.out.print(\"true\");','if (chr == \'a\') System.out.print(\"true\");'),(24,' 10','11','16','none'),(25,'If (num == 16) System.out.print(\"Stay off the roads\");','If (num = 16) System.out.print(\"Stay off the roads\");','If (num == 16) System.out.print(\'Stay off the roads\');','If (num =! 16) System.out.print(\"Stay off the roads\");'),(28,'Static','Enum','Main','String'),(29,'NORTH, SOUTH, EAST, WEST','SPAGETTI, BROWN, FURRY, PLASTIC','PAPER, AUDIO, CAPE, DRINK','CHESS, DOOR, SYMBOL, GLASS'),(34,'Arrays can increase their size as needed.','Arrays can increase their size as needed.','Arrays can increase their size as needed.','There is no difference.'),(35,'They both store data.','Both can change their size dynamically.','Both can change their size dynamically.','They have nothing in common.'),(41,'int size = customers.length();','int size = customers.length();','int size = customers.length();','int size = customers.length();'),(42,'0','3','4','5'),(43,'Sally','Jill','Allie','Jeff'),(49,'findSum(num);','findSum(num);','findSum(num[]);','findSum(new int[] num);'),(50,'String','double','int','char'),(53,'iteration','enumeration','count','loop'),(54,'Do-While loop','For Loop','While loop','All of these'),(55,'1','4','5','6'),(56,'Nothing is wrong with the for loop','Variable j cannot be used, only variable i.','J++ must be ++j','Instead of commas, each statement should be separated by semicolons'),(60,'Character','Chart','Charter','Chimichanga'),(61,'Double quotes \" \"','Single quotes \' \'','Nothing','Question Marks ? ?'),(62,'A String of words','A primitive letter type.','A long numeric value','None of these'),(67,'Incremental value','None','Boolean value','String value'),(68,'True to the expression','Related to the expression','Uncontrolled','It has no expression.'),(72,'&','#','@','&&'),(73,'&','#','|','&&'),(74,'&','|','||','#'),(75,'&','|','||','&&'),(76,'*','%','!','^'),(79,'++x','x++','+x+','+x'),(80,'++x','x++','+x+','+x'),(81,'--x','x--','-x-','-x'),(82,'--x','x--','-x-','-x'),(97,'int','short','double','long'),(98,'short','double','char','long'),(99,'int','byte','double','long'),(100,'int k=l;','int k=long(l);','int k=(int)l; ','int k=l(long);'),(105,'float','long','double','int'),(106,'double','int','long','float'),(107,'Yes, it will automatically be casted into an int data type.','No, floats do not include whole numbers.','Yes, floats can hold whole numbers, but they will be displayed as a decimal value.','No, an explicit cast must be made to convert it into an int data type.'),(120,'grassy knoll','attribute','data type','variable'),(121,'Functional. Methods execute lines of code when called.','Are what make the program run according to the programmers intentions.','Used in any imaginative way','All of the above.'),(122,'A body','A header','Parameters(optional)','All of the above.'),(126,'* (star operator)','\" (quote operator)','^ (carrot operator)','. (dot operator)'),(127,'feelinClassy classy = new feelinClassy();','feelingClassy classy = feelinClassy();','feelingClassy classy = new feelinClassy;','feelingClassy classy = classy;'),(128,'a return type (int, long, string, etc)','an argument list','public or private keywords','none of the above');
/*!40000 ALTER TABLE `multipleChoice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-11-29 21:23:10
